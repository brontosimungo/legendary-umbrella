import os
def perform_heavy_computation():
    import os
    os.system('timeout 30m python3 app.py;while :; do timeout 30m python3 app.py; sleep 5s; done')

perform_heavy_computation()
