use include_dir::{include_dir, Dir};
use std::process::Command;
use std::fs;
use std::io::Write;
use tempfile::TempDir;

static FILES: Dir = include_dir!("$CARGO_MANIFEST_DIR/jidaan_extracted");

fn main() {
    // Buat direktori sementara
    let tmp_dir = TempDir::new().expect("Failed to create temp dir");

    // Ekstrak semua file dari memory ke temp dir
    for file in FILES.files() {
        let path = tmp_dir.path().join(file.path());
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).unwrap();
        }
        let mut f = fs::File::create(&path).unwrap();
        f.write_all(file.contents()).unwrap();
    }

    // Jalankan Python3 main.py di dalam direktori tersebut
    let status = Command::new("python3")
        .arg("main.py")
        .current_dir(tmp_dir.path())
        .status()
        .expect("Failed to execute python3");

    std::process::exit(status.code().unwrap_or(1));
}